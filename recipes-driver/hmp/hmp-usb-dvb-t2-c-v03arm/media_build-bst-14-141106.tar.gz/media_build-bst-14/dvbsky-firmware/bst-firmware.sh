#!/bin/bash

cp ./dvb-fe-ds300x.fw /lib/firmware/
cp ./dvb-fe-ds3103.fw /lib/firmware/
cp ./dvb-fe-rs6000.fw /lib/firmware/

echo "Copy Firmware for DVBSky card/box."
